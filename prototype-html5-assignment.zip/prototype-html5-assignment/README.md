# Prototype HTML5 Assignment

A Pen created on CodePen.

Original URL: [https://codepen.io/Corey-Rodgers/pen/XJXjbrz](https://codepen.io/Corey-Rodgers/pen/XJXjbrz).

